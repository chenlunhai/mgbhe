<?php
/**
 * Created by xiaowei.wang
 * CreateTime: 16/7/7 上午10:42
 * Description:
 */

namespace Paymax\exception;


class AuthorizationException extends PaymaxException
{

}