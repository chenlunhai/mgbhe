<?php
/**
 * Created by xiaowei.wang
 * CreateTime: 16/7/7 上午10:41
 * Description:
 */

namespace Paymax\exception;


class InvalidResponseException extends PaymaxException
{

}